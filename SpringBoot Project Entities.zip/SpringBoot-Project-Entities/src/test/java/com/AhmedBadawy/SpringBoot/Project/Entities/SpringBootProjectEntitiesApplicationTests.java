package com.AhmedBadawy.SpringBoot.Project.Entities;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProjectEntitiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
