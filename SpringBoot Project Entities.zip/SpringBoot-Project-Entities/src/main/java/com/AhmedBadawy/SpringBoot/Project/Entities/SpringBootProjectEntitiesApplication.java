package com.AhmedBadawy.SpringBoot.Project.Entities;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProjectEntitiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProjectEntitiesApplication.class, args);
	}

}
